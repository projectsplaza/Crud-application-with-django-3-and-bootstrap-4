from django.shortcuts import render,redirect
from django.contrib import messages
from .forms import todoAddForm
from .models import Todo
# All Items
def all(request):
    items=Todo.objects.all()
    return render(request,'all.html',{
        'items':items
    })
# Add Method
def add(request):
    addForm=todoAddForm()
    if request.method=='POST':
        todoAdd=todoAddForm(request.POST)
        if todoAdd.is_valid():
            todoAdd.save()
            messages.success(request, 'Data has been added.')
            return redirect('/todo/add')
    return render(request,'add.html',{
        'form':addForm
    })

# Update Method
def update(request,id):
    item=Todo.objects.get(pk=id)
    updateForm=todoAddForm(instance=item)
    if request.method=='POST':
        todoAdd=todoAddForm(request.POST,instance=item)
        if todoAdd.is_valid():
            todoAdd.save()
            messages.success(request, 'Data has been updated.')
            return redirect('/todo/item/edit/'+str(id))
    return render(request,'update.html',{
        'form':updateForm,
        'item':item
    })

# Delete
def delete(request,id):
    Todo.objects.filter(id=id).delete()
    return redirect('/todo')
