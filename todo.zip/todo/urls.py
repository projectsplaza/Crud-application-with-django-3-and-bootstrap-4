from django.urls import path
from . import views
urlpatterns=[
    path('',views.all,name='all'),
    path('add',views.add,name='add'),
    path('item/edit/<int:id>',views.update,name='update'),
    path('item/delete/<int:id>',views.delete,name='delete'),
]